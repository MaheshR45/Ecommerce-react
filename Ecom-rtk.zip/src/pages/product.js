import React, { useEffect, useState } from "react";
import { product } from "../assets/data/data";
import "./product.css";
import { ProductCart } from "./ProductCart";

const Product = () => {
  const [gridClass, setGridClass] = useState(""); // State to hold the class name

  useEffect(() => {
    // Function to determine the screen size and set the class name accordingly
    const updateGridClass = () => {
      if (window.innerWidth < 768) {
        setGridClass("grid1"); // Mobile devices
      } else if (window.innerWidth < 1024) {
        setGridClass("grid2"); // Tablet devices
      } else {
        setGridClass("grid3"); // Desktop devices
      }
    };

    // Initial call to set the class on component mount
    updateGridClass();

    // Listen for window resize events to update the class on screen size changes
    window.addEventListener("resize", updateGridClass);

    // Clean up the event listener on component unmount
    return () => {
      window.removeEventListener("resize", updateGridClass);
    };
  }, []);

  return (
    <section className='product'>
      <div className={`container ${gridClass}`}>
        {product.map((item) => (
          <ProductCart key={item.id} id={item.id} cover={item.cover} name={item.name} price={item.price} />
        ))}
      </div>
    </section>
  );
};

export default Product;
