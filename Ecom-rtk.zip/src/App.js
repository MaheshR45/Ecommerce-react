import React from "react"
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Header from "./components/header/Header";
import Footer from "./components/footer/Footer";
import Home from "./components/home/Home"; 
import Account from "./pages/account";
import Login from "./pages/login";
import { useSelector } from "react-redux"


function App() {
  const isLoggIn = useSelector((state) => state.auth.isLoggIn)
  return (
    <div className="App">
       {isLoggIn && (
          <BrowserRouter>
            <Header />
            <Home />
            {/* <Routes>
              <Route index path='/' element={Home}  />
              <Route path='/account' element={Account} />
              <Route path='/login' element={Login} />
            </Routes> */}
            <Footer />
          </BrowserRouter>
       )}  
       {!isLoggIn && <Login />}
    </div>
  );
}

export default App;
