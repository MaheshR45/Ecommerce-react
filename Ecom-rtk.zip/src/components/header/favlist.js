import React from "react"
import { AiOutlineClose, AiOutlinePlus, AiOutlineMinus } from "react-icons/ai"
import { useDispatch } from "react-redux"
import { removeFromFav } from "../../redux/cartSlice"

export const FavList = ({ id, cover, name, price, quantity, totalPrice }) => {
  const dispatch = useDispatch()

//   const incCartitems = () => {
//     dispatch(addToCarts({ id, name, price }))
//   }
  const removefav = () => {
    dispatch(removeFromFav(id))
  }
  return (
    <>
      <div className='cardList' key={id}>
        <div className='cartContent'>
          <div className='img'>
            <img src={cover} alt='' />
            <button className='remove flexCenter'>
              <AiOutlineClose />
            </button>
          </div>
          <div className='details'>
            <p>{name}</p>
            <label htmlFor=''>Unit Price ${price}</label>

            <div className='price'>
              <div className='qty flexCenter'>
                {/* <button className='plus' onClick={incCartitems}>
                  <AiOutlinePlus />
                </button>
                <button className='num'>1{quantity}</button>*/}
                <button className='minus' onClick={removefav}>
                  <AiOutlineMinus />
                </button> 
              </div>
              <div className='priceTitle'>${totalPrice}</div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

