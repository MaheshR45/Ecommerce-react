import React, { useState } from "react"
import { BiShoppingBag } from "react-icons/bi"
import { AiOutlineClose } from "react-icons/ai"
import { FavList } from "./favlist"
import { useSelector } from "react-redux"
import { FaHeart } from "react-icons/fa";



const Fav = () => {
  const [cardOpen, setCardOpen] = useState(false)
  const closeCard = () => {
    setCardOpen(null)
  }
  
  const favItems = useSelector((state) => state.cart.favList)
  const favquantity = useSelector((state) => state.cart.totalFavQuantity)

  return (
    <>
      <div className='card' style={{marginRight:"10px"}} onClick={() => setCardOpen(!cardOpen)}>
        <FaHeart className='cardIcon' /> 
        <span className='flexCenter'>{favquantity}</span>
      </div>
      <div className={cardOpen ? "cartItem" : "cardhide"}>
        <div className='title flex'>
          <h2>Favourite List</h2>
          <button onClick={closeCard}>
            <AiOutlineClose className='icon' />
          </button>
        </div>
        {favItems.map((item) => (
          <FavList id={item.id} cover={item.cover} name={item.name} price={item.price} quantity={item.quantity} totalPrice={item.totalPrice} />
        ))}

        {/* <div className='checkOut'>
          <button>
            <span>Priceed To Checkout</span>
            <label htmlFor=''>${total}</label>
          </button>
        </div> */}
      </div>
    </>
  )
}
export default Fav
